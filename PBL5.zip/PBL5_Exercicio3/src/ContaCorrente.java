public class ContaCorrente extends Conta {
    public ContaCorrente(float valor) {
        super(valor);
    }
}
