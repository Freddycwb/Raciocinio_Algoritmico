public class Gato extends Animal {
    @Override
    public void fazerBarulho() { System.out.println("miau"); }
}
