public class Main {
    public static void main(String[] args) {
        Veiculo carro = new Carro();
        Veiculo moto = new Moto();

        carro.Acelerar();
        moto.Acelerar();
    }
}