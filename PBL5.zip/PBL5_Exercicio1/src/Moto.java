public class Moto extends Veiculo {
    @Override
    public void Acelerar() {
        System.out.println("Moto acelerou.");
    }
}
