public class Carro extends Veiculo {
    @Override
    public void Acelerar() {
        System.out.println("Carro acelerou.");
    }
}
