public class Veiculo {
    public void Acelerar() {
        return;
    }
}
