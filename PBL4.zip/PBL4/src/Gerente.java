public class Gerente extends Pessoa{
    public Gerente(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    @Override
    public String getTipo() { return "gerente"; }
}
