public class Funcionario extends Pessoa{
    public Funcionario(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    @Override
    public String getTipo() { return "funcionario"; }
}
