import java.util.Scanner;
import java.util.ArrayList;

public class Menu {
    private Scanner input;
    private ArrayList<Pessoa> pessoas = new ArrayList<>();

    public Menu() {
        input = new Scanner(System.in);
    }

    public void exibir() {
        int opcao = -1;

        while(opcao != 0) {
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Cadastrar pessoa");
            System.out.println("2 - Listar pessoas");
            System.out.println("3 - Buscar pessoas por tipo");
            System.out.println("0 - Sair");

            opcao = input.nextInt();

            if (opcao == 1) {
                pessoas.add(CadastrarPessoa());
                System.out.println("Pessoa cadastrada com sucesso.");
            } else if (opcao == 2) {
                listarPessoas();
            } else if (opcao == 3) {
                buscarPessoasPorTipo();
            } else if (opcao == 0) {
                System.out.println("Saindo do sistema...");
            } else {
                System.out.println("Opção inválida. Tente novamente.");
            }
        }
        input.close();
    }

    public Pessoa CadastrarPessoa() {
        System.out.println("Cadastro de pessoa selecionado.");
        System.out.println("Por favor, informe os dados da pessoa:");
        System.out.print("Nome: ");
        String nome = input.next();
        System.out.print("Idade: ");
        int idade = input.nextInt();
        System.out.print("Tipo (1 - cliente/ 2 - funcionario/3 - gerente): ");
        switch (Integer.parseInt(input.next())) {
            case 2:
                return new Funcionario(nome, idade);
            case 3:
                return new Gerente(nome, idade);
            default:
                return new Cliente(nome, idade);
        }
    }

    public void listarPessoas() {
        System.out.println("Listagem de pessoas selecionada.");
        for (Pessoa p : pessoas) {
            System.out.println(" - " + p.getNome() + ", " + p.getIdade() + " anos, " + p.getTipo());
        }
    }

    public void buscarPessoasPorTipo() {
        System.out.println("Busca de pessoas por tipo selecionada.");
        System.out.print("Por favor, informe o tipo de pessoa para procurar");
        System.out.print("Tipo (1 - cliente/ 2 - funcionario/3 - gerente): ");
        int tipo = Integer.parseInt(input.next());
        for (Pessoa p : pessoas) {
            switch (tipo) {
                case 2:
                    if (p instanceof Funcionario) {
                        System.out.println(" - " + p.getNome() + ", " + p.getIdade() + " anos, " + p.getTipo());
                    }
                    break;
                case 3:
                    if (p instanceof Gerente) {
                        System.out.println(" - " + p.getNome() + ", " + p.getIdade() + " anos, " + p.getTipo());
                    }
                    break;
                default:
                    if (p instanceof Cliente) {
                        System.out.println(" - " + p.getNome() + ", " + p.getIdade() + " anos, " + p.getTipo());
                    }
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.exibir();
    }
}