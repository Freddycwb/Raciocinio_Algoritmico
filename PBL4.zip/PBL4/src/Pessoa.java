import java.util.Scanner;
class Pessoa {
    protected String nome;
    protected int idade;

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getTipo() { return ""; }
}